package models

import (
	"github.com/jinzhu/gorm"
	"time"
)

type Student struct {
	gorm.Model
	GId             uint
	MentorId        uint
	MentorEmail     string
	Name            string
	Password        string `gorm:"not null"`
	Gender          string
	Age             uint8
	Country         string
	City            string
	School          string
	MathEnabled     bool
	EnEnabled       bool
	VrEnabled       bool
	NvrEnabled      bool
	Activity        uint
	Stickers        uint
	Stars           uint
	TaskDone        uint
	TaskPass        uint
	IsMember        bool
	MembershipStart time.Time
	MembershipStop  time.Time
	LastLoginTime   time.Time
	LoginCount      uint
	AiEnabled       bool
	LevelMath       uint8
	LevelEn         uint8
	LevelVr         uint8
	LevelNvr        uint8
	Assignments     []assignment
	StickerLog      []string
	Contacts        []string
	KpStatusLog     []KpStatus
}

type assignment struct {
	KpId   string
	Done   bool
	Pass   bool
	Desc   string
	Weight uint
}

type KpStatus struct {
	KpId         string
	MasterLevel  uint
	TotalQue     uint
	AvgPerc      uint
	ReviseState  uint
	QueIndex     uint
	LastDoneTime time.Time
}
