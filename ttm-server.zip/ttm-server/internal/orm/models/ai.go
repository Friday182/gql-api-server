package models

import (
	"github.com/jinzhu/gorm"
)

type KpLog struct {
	KpId       string
	NumQue     uint
	CorrectQue uint
	MaxSeconds uint
	MinSeconds uint
	AvgSeconds uint
}

type TaskLog struct {
	gorm.Model
	UserId        uint
	Name          string
	Total_que     uint
	Total_correct uint
	total_sec     uint
	total_score   uint
	Kps           []KpLog
	dummy1        uint
	dummy2        uint
}
