package models

type KpDescription struct {
	ID          uint `gorm:"primary_key"`
	KpId        string
	Title       string
	Description string
	Example     string
	Note        string
}

type Question struct {
	ID           uint   `gorm:"primary_key"`
	KpId         string `sql:"index"`
	StdSec       uint
	AnswerType   string
	QuestionType string
	QuestionText string `gorm:"size:5000"`
	ChartType    string
	Options      string `gorm:"size:2000"`
	Answers      string `gorm:"size:2000"`
	Tags         string `gorm:"size:2000"`
	Charts       string `gorm:"size:4000"`
	Clocks       string `gorm:"size:1000"`
	Tables       string `gorm:"size:4000"`
	option1      string
	option2      string
	option3      string
	option4      string
	answer1      string
	answer2      string
	answer3      string
	answer4      string
	answer_text  string
	helper       string
	img1         string
	img2         string
	tag1         string
	tag2         string
	tip          string
}
