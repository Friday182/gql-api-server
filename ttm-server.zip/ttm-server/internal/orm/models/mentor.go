package models

import (
	"github.com/jinzhu/gorm"
	"time"
)

type Mentor struct {
	gorm.Model
	GId            uint
	Name           string
	Email          string `gorm:"type:varchar(100);unique_index"`
	Password       string `gorm:"not null"`
	Gender         string
	Age            string
	Country        string
	City           string
	Role           string
	PromotionCode  string
	StudentMax     uint
	StudentNum     uint
	Contacts       []string
	VerifyCode     string
	LastSigninTime time.Time
	SigninCount    uint
	dummy1         string
	dummy2         string
}
